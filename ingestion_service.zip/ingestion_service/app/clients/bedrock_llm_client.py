import time
from typing import Any

from openai import APIConnectionError, APIStatusError, APITimeoutError, OpenAI

from app.config.settings import settings


class BedrockLLMClient:
    """OpenAI-compatible Amazon Bedrock Chat Completions client."""

    def __init__(self) -> None:
        if not settings.BEDROCK_API_KEY:
            raise ValueError("BEDROCK_API_KEY is not configured.")

        self.model = settings.BEDROCK_LLM_MODEL
        self.max_retries = settings.BEDROCK_LLM_MAX_RETRIES
        self.client = OpenAI(
            api_key=settings.BEDROCK_API_KEY,
            base_url=settings.BEDROCK_LLM_BASE_URL,
            timeout=settings.BEDROCK_LLM_TIMEOUT,
            max_retries=0,  # Finzer owns the retry policy below.
        )

    def chat_completion(
        self,
        *,
        messages: list[dict[str, str]],
        max_tokens: int,
        temperature: float,
    ) -> dict[str, Any]:
        total_attempts = self.max_retries + 1

        for attempt in range(1, total_attempts + 1):
            try:
                print(f"Bedrock LLM request attempt {attempt}/{total_attempts}")
                response = self.client.chat.completions.create(
                    model=self.model,
                    messages=messages,
                    max_tokens=max_tokens,
                    temperature=temperature,
                )
                content = response.choices[0].message.content
                if not content:
                    raise RuntimeError("Bedrock LLM returned empty content.")
                return {"choices": [{"message": {"content": content}}]}

            except (APITimeoutError, APIConnectionError) as exc:
                if attempt >= total_attempts:
                    raise
                wait_seconds = 2 ** attempt
                print(f"Transient Bedrock LLM failure: {exc}")
                print(f"Retrying in {wait_seconds} seconds...")
                time.sleep(wait_seconds)

            except APIStatusError as exc:
                # Retry throttling and transient server failures only.
                if exc.status_code not in {429, 500, 502, 503, 504} or attempt >= total_attempts:
                    raise
                wait_seconds = 2 ** attempt
                print(f"Transient Bedrock HTTP {exc.status_code}: {exc}")
                print(f"Retrying in {wait_seconds} seconds...")
                time.sleep(wait_seconds)

        raise RuntimeError("Bedrock LLM request failed unexpectedly.")
