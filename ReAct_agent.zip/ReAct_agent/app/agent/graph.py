
"""Finzer ReAct graph with Phase 5 governance and approved-write resume."""
from __future__ import annotations

from typing import Any, Literal, Protocol, TypedDict

from langgraph.graph import END, START, StateGraph
from pydantic import BaseModel, Field, model_validator

from app.agent.context import ContextManager, PreparedContext
from app.agent.state import (
    AgentError,
    ApprovalStatus,
    AgentState,
    ConversationMessage,
    ExecutionStatus,
    MessageRole,
    NextAction,
    ObservationStatus,
    ToolCall,
    ToolError,
    ToolObservation,
)
from app.tools.contracts import ToolOperation
from app.governance.models import PolicyDecision
from app.governance.policy import GovernancePolicyEngine
from app.governance.approval import ApprovalManager
from app.governance.audit import GovernanceAuditLogger
from app.tools.registry import get_tool_contract, list_tool_contracts


class AgentDecision(BaseModel):
    """Structured output expected from a decision-model adapter."""

    action: Literal["tool", "clarify", "finish"]
    tool_name: str | None = None
    arguments: dict[str, Any] = Field(default_factory=dict)
    message: str | None = None

    @model_validator(mode="after")
    def check_action(self) -> "AgentDecision":
        if self.action == "tool" and not self.tool_name:
            raise ValueError("Tool decisions require tool_name")
        if self.action in ("clarify", "finish") and not (self.message or "").strip():
            raise ValueError("Clarify/finish decisions require message")
        return self


class DecisionModel(Protocol):
    def decide(
        self,
        *,
        context: PreparedContext,
        available_tools: list[Any],
    ) -> AgentDecision: ...


class ToolExecutor(Protocol):
    def execute(
        self,
        *,
        tool_name: str,
        arguments: dict[str, Any],
        **kwargs: Any,
    ) -> Any: ...


class _GraphState(TypedDict):
    agent: AgentState


class ReActGraph:
    """Synchronous ReAct graph with governance and approval support."""

    def __init__(
        self,
        *,
        decision_model: DecisionModel,
        tool_executor: ToolExecutor,
        context_manager: ContextManager | None = None,
        max_steps: int = 8,
        max_tool_calls: int = 5,
        policy_engine: GovernancePolicyEngine | None = None,
        approval_manager: ApprovalManager | None = None,
        audit_logger: GovernanceAuditLogger | None = None,
        user_context_available: bool = False,
    ) -> None:
        if max_steps < 1 or max_tool_calls < 1:
            raise ValueError(
                "max_steps and max_tool_calls must be positive"
            )

        self.decision_model = decision_model
        self.tool_executor = tool_executor
        self.context_manager = context_manager or ContextManager()
        self.max_steps = max_steps
        self.max_tool_calls = max_tool_calls

        self.policy_engine = policy_engine or GovernancePolicyEngine()
        self.approval_manager = approval_manager or ApprovalManager()
        self.audit_logger = audit_logger or GovernanceAuditLogger()
        self.user_context_available = user_context_available

        # Graph and executor must share the same approval manager.
        if not hasattr(tool_executor, "approval_manager"):
            self._write_executor_ready = False
        else:
            configured_manager = tool_executor.approval_manager

            if configured_manager is None:
                tool_executor.approval_manager = self.approval_manager
            elif configured_manager is not self.approval_manager:
                raise ValueError(
                    "Graph and executor must share one ApprovalManager"
                )

            self._write_executor_ready = True

        builder = StateGraph(_GraphState)

        builder.add_node("decide", self._decide)
        builder.add_node("execute", self._execute)

        builder.add_edge(START, "decide")

        builder.add_conditional_edges(
            "decide",
            self._route,
            {"execute": "execute", "end": END},
        )

        builder.add_edge("execute", "decide")

        self.graph = builder.compile()

    @staticmethod
    def _fail(
        state: AgentState,
        error_type: str,
        message: str,
    ) -> None:
        state.errors.append(
            AgentError(
                type=error_type,
                message=message,
                step=state.step_count,
            )
        )
        state.next_action = NextAction.FINISH
        state.pending_tool_call = None
        state.execution_status = ExecutionStatus.FAILED

    def _decide(self, graph_state: _GraphState) -> _GraphState:
        state = graph_state["agent"].model_copy(deep=True)

        if state.step_count >= self.max_steps:
            self._fail(
                state,
                "STEP_LIMIT",
                "Maximum reasoning steps reached",
            )
            return {"agent": state}

        if state.tool_call_count >= self.max_tool_calls:
            self._fail(
                state,
                "TOOL_LIMIT",
                "Maximum tool calls reached",
            )
            return {"agent": state}

        state.step_count += 1
        state.next_action = NextAction.DECIDE

        try:
            context = self.context_manager.prepare_context(state)

            # Write tools are discoverable only with a user identity
            # and an approval-aware executor.
            available = [
                contract
                for contract in list_tool_contracts()
                if contract.operation == ToolOperation.READ
                or (state.user_id and self._write_executor_ready)
            ]

            decision = self.decision_model.decide(
                context=context,
                available_tools=available,
            )

            if not isinstance(decision, AgentDecision):
                decision = AgentDecision.model_validate(decision)

        except Exception as exc:
            self._fail(state, "DECISION_ERROR", str(exc))
            return {"agent": state}

        if decision.action == "tool":
            contract = get_tool_contract(decision.tool_name or "")

            if contract is None:
                self._fail(
                    state,
                    "UNKNOWN_TOOL",
                    f"Unknown tool: {decision.tool_name}",
                )
            else:
                call = ToolCall(
                    tool_name=decision.tool_name or "",
                    arguments=decision.arguments,
                )
                state.pending_tool_call = call
                self._authorize_or_pause(state, call)

        elif decision.action == "clarify":
            state.pending_tool_call = None
            state.final_answer = decision.message
            state.next_action = NextAction.CLARIFY
            state.execution_status = ExecutionStatus.WAITING_FOR_USER

            state.messages.append(
                ConversationMessage(
                    role=MessageRole.ASSISTANT,
                    content=decision.message or "",
                )
            )

        else:
            state.pending_tool_call = None
            state.final_answer = decision.message
            state.next_action = NextAction.FINISH
            state.execution_status = ExecutionStatus.COMPLETED

            state.messages.append(
                ConversationMessage(
                    role=MessageRole.ASSISTANT,
                    content=decision.message or "",
                )
            )

        return {"agent": state}

    def _authorize_or_pause(
        self,
        state: AgentState,
        call: ToolCall,
    ) -> None:
        evaluation = self.policy_engine.evaluate(
            tool_call=call,
            user_context_available=self.user_context_available,
            explicit_user_authorization=False,
        )

        self.audit_logger.record_policy(
            run_id=state.run_id,
            evaluation=evaluation,
        )

        if evaluation.decision == PolicyDecision.DENY:
            self.audit_logger.record_tool_blocked(
                run_id=state.run_id,
                tool_name=call.tool_name,
                call_id=call.call_id,
                reason=evaluation.reason,
            )
            self._fail(
                state,
                "POLICY_DENIED",
                evaluation.reason,
            )
            return

        if evaluation.decision == PolicyDecision.REQUIRE_APPROVAL:
            if not state.user_id:
                self._fail(
                    state,
                    "USER_ID_REQUIRED",
                    "Approval requires authenticated user identity",
                )
                return

            request = self.approval_manager.create_request(
                run_id=state.run_id,
                user_id=state.user_id,
                tool_call=call,
                reason=evaluation.reason,
            )

            self.audit_logger.record_approval_request(
                request=request
            )

            state.approval.status = ApprovalStatus.PENDING
            state.approval.call_id = call.call_id
            state.approval.reason = (
                f"{evaluation.reason} "
                f"[request_id={request.request_id}]"
            )

            state.next_action = NextAction.WAIT_APPROVAL
            state.execution_status = (
                ExecutionStatus.WAITING_FOR_APPROVAL
            )
            return

        state.approval.status = ApprovalStatus.NOT_REQUIRED
        state.approval.call_id = None
        state.approval.reason = None
        state.next_action = NextAction.TOOL

    @staticmethod
    def _route(
        graph_state: _GraphState,
    ) -> Literal["execute", "end"]:
        state = graph_state["agent"]

        if (
            state.execution_status == ExecutionStatus.RUNNING
            and state.next_action == NextAction.TOOL
        ):
            return "execute"

        return "end"

    def _execute(self, graph_state: _GraphState) -> _GraphState:
        state = graph_state["agent"].model_copy(deep=True)
        self._execute_tool(state)
        return {"agent": state}

    def _execute_tool(
        self,
        state: AgentState,
        *,
        approval_request_id: str | None = None,
    ) -> None:
        call = state.pending_tool_call

        if call is None:
            self._fail(
                state,
                "MISSING_TOOL_CALL",
                "No pending tool call",
            )
            return

        if state.tool_call_count >= self.max_tool_calls:
            self._fail(
                state,
                "TOOL_LIMIT",
                "Maximum tool calls reached",
            )
            return

        contract = get_tool_contract(call.tool_name)

        if contract is None:
            self._fail(
                state,
                "UNKNOWN_TOOL",
                "Unregistered tool",
            )
            return

        if approval_request_id is None:
            if state.approval.status == ApprovalStatus.PENDING:
                self._fail(
                    state,
                    "APPROVAL_PENDING",
                    "Tool is awaiting approval",
                )
                return

            evaluation = self.policy_engine.evaluate(
                tool_call=call,
                user_context_available=self.user_context_available,
                explicit_user_authorization=False,
            )

            if (
                evaluation.decision != PolicyDecision.ALLOW
                or contract.operation != ToolOperation.READ
            ):
                self._fail(
                    state,
                    "POLICY_DENIED",
                    evaluation.reason,
                )
                return

        else:
            if (
                contract.operation != ToolOperation.WRITE
                or state.approval.status != ApprovalStatus.APPROVED
            ):
                self._fail(
                    state,
                    "APPROVAL_INVALID",
                    "Approved write required",
                )
                return

            if not state.user_id or not self._write_executor_ready:
                self._fail(
                    state,
                    "APPROVAL_INVALID",
                    "Verified write executor unavailable",
                )
                return

        state.tool_call_count += 1

        try:
            kwargs = {}

            if approval_request_id is not None:
                kwargs = {
                    "run_id": state.run_id,
                    "user_id": state.user_id,
                    "call_id": call.call_id,
                    "approval_request_id": approval_request_id,
                }

            result = self.tool_executor.execute(
                tool_name=call.tool_name,
                arguments=call.arguments,
                **kwargs,
            )

            if isinstance(result, BaseModel):
                result = result.model_dump(mode="json")

            if isinstance(result, dict) and (
                result.get("status") == "error"
                or result.get("isError") is True
            ):
                raise RuntimeError(
                    str(result.get("error") or result)
                )

            observation = ToolObservation(
                call_id=call.call_id,
                tool_name=call.tool_name,
                status=ObservationStatus.SUCCESS,
                data=result,
            )

        except Exception as exc:
            observation = ToolObservation(
                call_id=call.call_id,
                tool_name=call.tool_name,
                status=ObservationStatus.ERROR,
                error=ToolError(
                    type="TOOL_EXECUTION_ERROR",
                    message=str(exc),
                ),
            )

        self.audit_logger.record_tool_executed(
            run_id=state.run_id,
            tool_name=call.tool_name,
            call_id=call.call_id,
            success=(
                observation.status == ObservationStatus.SUCCESS
            ),
        )

        state.observations.append(observation)

        # Change the action before clearing the pending tool call.
        # AgentState validates every field assignment.
        state.next_action = NextAction.DECIDE
        state.pending_tool_call = None

    def resolve_approval(
        self,
        *,
        state: AgentState,
        request_id: str,
        user_id: str,
        approve: bool,
    ) -> AgentState:
        """
        Resolve a pending approval, execute the approved
        write once, and resume the ReAct reasoning loop.
        """

        resumed = state.model_copy(deep=True)

        if (
            resumed.execution_status
            != ExecutionStatus.WAITING_FOR_APPROVAL
            or resumed.pending_tool_call is None
            or resumed.approval.status != ApprovalStatus.PENDING
        ):
            raise ValueError(
                "Agent is not waiting for approval"
            )

        # Request ID is stored in the existing Approval.reason.
        if not (
            resumed.approval.reason or ""
        ).endswith(f"[request_id={request_id}]"):
            raise ValueError(
                "Approval request does not belong to this state"
            )

        request = self.approval_manager.get_request(request_id)

        if (
            request.run_id != resumed.run_id
            or request.user_id != user_id
            or request.tool_call != resumed.pending_tool_call
            or resumed.user_id != user_id
        ):
            raise ValueError(
                "Approval request does not match run, user, or tool"
            )

        resolution = self.approval_manager.resolve(
            request_id=request_id,
            user_id=user_id,
            approve=approve,
        )

        self.audit_logger.record_approval_resolution(
            run_id=resumed.run_id,
            resolution=resolution,
        )

        if not approve:
            resumed.approval.status = ApprovalStatus.DENIED
            self._fail(
                resumed,
                "APPROVAL_DENIED",
                "User rejected the tool operation",
            )
            return resumed

        call = resumed.pending_tool_call

        if not self.approval_manager.validate_resume(
            request_id=request_id,
            run_id=resumed.run_id,
            user_id=user_id,
            tool_call=call,
        ):
            self._fail(
                resumed,
                "APPROVAL_INVALID",
                "Approval is invalid or expired",
            )
            return resumed

        resumed.approval.status = ApprovalStatus.APPROVED
        resumed.execution_status = ExecutionStatus.RUNNING
        resumed.next_action = NextAction.TOOL

        self.audit_logger.record_agent_resumed(
            run_id=resumed.run_id,
            request_id=request_id,
        )

        self._execute_tool(
            resumed,
            approval_request_id=request_id,
        )

        if resumed.execution_status != ExecutionStatus.RUNNING:
            return resumed

        # Continue reasoning with the new tool observation.
        return self.graph.invoke(
            {"agent": resumed},
            config={
                "recursion_limit": 2 * self.max_steps + 4
            },
        )["agent"]

    def run(self, state: AgentState) -> AgentState:
        """Execute one bounded ReAct run."""

        initial = state.model_copy(deep=True)

        if initial.execution_status != ExecutionStatus.RUNNING:
            raise ValueError(
                "AgentState must have execution_status=RUNNING"
            )

        result = self.graph.invoke(
            {"agent": initial},
            config={
                "recursion_limit": 2 * self.max_steps + 4
            },
        )

        return result["agent"]
